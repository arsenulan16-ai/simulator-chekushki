
import pygame
import math
import os
import json
import sys

pygame.init()

# ==========================================
# НАСТРОЙКИ ЭКРАНА
# ==========================================

WIDTH, HEIGHT = 900, 500
FPS = 60

BASE = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = os.path.join(BASE, "skins_save.json")

# Игра всегда рисуется в 900x500.
# На монитор выводится увеличенная копия
# с сохранением пропорций.
screen = pygame.Surface((WIDTH, HEIGHT))

info = pygame.display.Info()
MONITOR_W = info.current_w
MONITOR_H = info.current_h

fullscreen = True
display = None
scale = 1
offset_x = 0
offset_y = 0
game_w = WIDTH
game_h = HEIGHT


def setup_display():
    global display, scale, offset_x, offset_y
    global game_w, game_h

    if fullscreen:
        display = pygame.display.set_mode(
            (MONITOR_W, MONITOR_H),
            pygame.FULLSCREEN
        )
        dw, dh = display.get_size()
    else:
        display = pygame.display.set_mode(
            (WIDTH, HEIGHT)
        )
        dw, dh = display.get_size()

    scale = min(dw / WIDTH, dh / HEIGHT)

    game_w = max(1, round(WIDTH * scale))
    game_h = max(1, round(HEIGHT * scale))

    offset_x = (dw - game_w) // 2
    offset_y = (dh - game_h) // 2

    pygame.display.set_caption("СИМУЛЯТОР ЧЕКУШКИ v1.0")


def toggle_fullscreen():
    global fullscreen
    fullscreen = not fullscreen
    setup_display()


def mouse_to_game(pos):
    mx, my = pos

    return (
        int((mx - offset_x) / scale),
        int((my - offset_y) / scale)
    )


def present():
    display.fill((0, 0, 0))

    if game_w == WIDTH and game_h == HEIGHT:
        display.blit(screen, (offset_x, offset_y))
    else:
        scaled = pygame.transform.smoothscale(
            screen, (game_w, game_h)
        )
        display.blit(scaled, (offset_x, offset_y))

    pygame.display.flip()


setup_display()

clock = pygame.time.Clock()

# ==========================================
# ЦВЕТА И ШРИФТЫ
# ==========================================

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 40, 220)
GREEN = (30, 190, 50)
DARK_GREEN = (15, 130, 35)
RED = (230, 20, 20)
YELLOW = (255, 220, 50)
GRAY = (150, 150, 150)
BROWN = (135, 80, 40)

font = pygame.font.SysFont("arial", 36, bold=True)
small_font = pygame.font.SysFont("arial", 24, bold=True)
big_font = pygame.font.SysFont("arial", 60, bold=True)
title_font = pygame.font.SysFont("arial", 42, bold=True)
intro_font = pygame.font.SysFont("arial", 85, bold=True)
version_font = pygame.font.SysFont("arial", 18)

# ==========================================
# ЗАГРУЗКА КАРТИНОК
# ==========================================

def load_image(filename, size):
    path = os.path.join(BASE, filename)

    if not os.path.exists(path):
        return None

    try:
        image = pygame.image.load(path).convert_alpha()
        return pygame.transform.smoothscale(image, size)
    except pygame.error as error:
        print("Ошибка картинки:", filename, error)
        return None


menu_bg = load_image("fon.png", (WIDTH, HEIGHT))
bottle_img = load_image("bottle.png", (40, 75))

level_backgrounds = {}

for number in range(1, 21):
    level_backgrounds[number] = load_image(
        f"level{number}.png",
        (WIDTH, HEIGHT)
    )

# ==========================================
# ТЕКСТ И КНОПКИ
# ==========================================

def draw_text(text, used_font, color, center):
    image = used_font.render(str(text), True, color)
    rect = image.get_rect(center=center)
    screen.blit(image, rect)


def draw_button(rect, label, color=GREEN):
    pygame.draw.rect(
        screen,
        color,
        rect,
        border_radius=12
    )

    pygame.draw.rect(
        screen,
        (100, 255, 110),
        rect,
        3,
        border_radius=12
    )

    draw_text(
        label,
        small_font,
        WHITE,
        rect.center
    )


def draw_arrows():
    pygame.draw.polygon(
        screen,
        WHITE,
        [(275, 255), (325, 215), (325, 295)]
    )

    pygame.draw.polygon(
        screen,
        WHITE,
        [(625, 255), (575, 215), (575, 295)]
    )


play_button = pygame.Rect(330, 170, 240, 75)
skins_button = pygame.Rect(360, 260, 180, 50)
music_button = pygame.Rect(370, 325, 160, 45)

back_button = pygame.Rect(15, 15, 135, 50)

left_button = pygame.Rect(260, 210, 90, 90)
right_button = pygame.Rect(550, 210, 90, 90)

buy_button = pygame.Rect(335, 405, 230, 55)

music_toggle = pygame.Rect(335, 345, 230, 60)

reset_button = pygame.Rect(765, 90, 120, 45)


def draw_back():
    draw_button(back_button, "НАЗАД")


# ==========================================
# ЗВУКИ И МУЗЫКА
# ==========================================

def load_sound(filename):
    if not pygame.mixer.get_init():
        return None

    path = os.path.join(BASE, filename)

    if not os.path.exists(path):
        return None

    try:
        return pygame.mixer.Sound(path)
    except pygame.error as error:
        print("Ошибка звука:", filename, error)
        return None


intro_sound = load_sound("intro.mp3")
win_sound = load_sound("win.mp3")

TRACKS = [
    ("Музыка 1", "music1.mp3"),
    ("Музыка 2", "music2.mp3"),
    ("Музыка 3", "music3.mp3")
]

music_index = 0
music_enabled = False


def stop_music():
    if pygame.mixer.get_init():
        pygame.mixer.music.stop()


def play_music():
    if not pygame.mixer.get_init():
        return

    filename = TRACKS[music_index][1]
    path = os.path.join(BASE, filename)

    if not os.path.exists(path):
        print("Нет музыкального файла:", filename)
        return

    try:
        pygame.mixer.music.load(path)
        pygame.mixer.music.set_volume(0.35)
        pygame.mixer.music.play(-1)
    except pygame.error as error:
        print("Ошибка музыки:", error)


# ==========================================
# МАГАЗИН СКИНОВ
# ==========================================

SKINS = [
    {
        "name": "Обычный",
        "file": "player.png",
        "price": 0
    },
    {
        "name": "Красный",
        "file": "skin_red.png",
        "price": 20
    },
    {
        "name": "Зелёный",
        "file": "skin_green.png",
        "price": 40
    },
    {
        "name": "Испуганость",
        "file": "skin_scared.png",
        "price": 30
    },
    {
        "name": "Серьёзность",
        "file": "skin_serious.png",
        "price": 40
    },
    {
        "name": "Артур",
        "file": "skin_artur.png",
        "price": 60
    }
]


def make_placeholder(index):
    image = pygame.Surface((75, 100), pygame.SRCALPHA)

    colors = [
        (255, 230, 70),
        (230, 50, 50),
        (40, 210, 60),
        (170, 100, 210),
        (90, 90, 90),
        (60, 110, 220)
    ]

    color = colors[index % len(colors)]

    pygame.draw.circle(image, (255, 220, 170), (37, 18), 15)
    pygame.draw.rect(image, color, (18, 34, 38, 43))
    pygame.draw.rect(image, BLACK, (18, 75, 15, 24))
    pygame.draw.rect(image, BLACK, (41, 75, 15, 24))
    pygame.draw.rect(image, color, (5, 38, 13, 33))
    pygame.draw.rect(image, color, (57, 38, 13, 33))

    return image


skin_images = []

for index, skin in enumerate(SKINS):
    image = load_image(skin["file"], (75, 100))

    if image is None:
        image = make_placeholder(index)

    skin_images.append(image)


coins = 100
owned = [0]
selected_skin = 0
shop_index = 0


def save_data():
    data = {
        "coins": coins,
        "owned": owned,
        "selected": selected_skin
    }

    try:
        with open(SAVE_FILE, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
    except OSError as error:
        print("Ошибка сохранения:", error)


def load_save():
    global coins, owned, selected_skin

    if not os.path.exists(SAVE_FILE):
        return

    try:
        with open(SAVE_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)

        coins = max(0, int(data.get("coins", 100)))

        saved_owned = data.get("owned", [0])

        owned = [
            int(index)
            for index in saved_owned
            if isinstance(index, int)
            and 0 <= index < len(SKINS)
        ]

        if 0 not in owned:
            owned.append(0)

        selected_skin = int(data.get("selected", 0))

        if selected_skin not in owned:
            selected_skin = 0

    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        print("Не удалось прочитать сохранение.")


def reset_shop():
    global coins, owned, selected_skin, shop_index

    coins = 0
    owned = [0]
    selected_skin = 0
    shop_index = 0

    save_data()


load_save()

# ==========================================
# УРОВНИ
# ==========================================

LEVELS = {
    1: {
        "boxes": [
            pygame.Rect(0, 340, 145, 160),
            pygame.Rect(165, 340, 180, 160),
            pygame.Rect(420, 340, 190, 160),
            pygame.Rect(740, 330, 160, 170),
            pygame.Rect(423, 0, 174, 174)
        ],
        "anchor": (350, 15),
        "length": 120,
        "bottle": (810, 255)
    },

    2: {
        "boxes": [
            pygame.Rect(0, 0, 260, 103),
            pygame.Rect(366, 0, 193, 160),
            pygame.Rect(775, 0, 125, 63),
            pygame.Rect(740, 224, 160, 170),
            pygame.Rect(373, 360, 173, 140)
        ],
        "anchor": (130, 30),
        "length": 135,
        "bottle": (810, 149)
    },

    3: {
        "boxes": [
            pygame.Rect(0, 0, 230, 108),
            pygame.Rect(440, 0, 270, 132),
            pygame.Rect(112, 345, 788, 155)
        ],
        "anchor": (95, 30),
        "length": 125,
        "bottle": (850, 270)
    },

    4: {
        "boxes": [
            pygame.Rect(0, 0, 310, 140),
            pygame.Rect(685, 0, 215, 145),
            pygame.Rect(320, 405, 165, 95),
            pygame.Rect(485, 365, 220, 135),
            pygame.Rect(710, 405, 170, 95)
        ],
        "anchor": (390, 35),
        "length": 315,
        "bottle": (735, 245)
    }
}

# Временные уровни до обновления v1.2
for number in range(5, 21):
    LEVELS[number] = {
        "boxes": [
            pygame.Rect(0, 0, 220, 100),
            pygame.Rect(340, 0, 180, 130),
            pygame.Rect(650, 0, 180, 105),
            pygame.Rect(150, 365, 180, 135),
            pygame.Rect(440, 340, 180, 160),
            pygame.Rect(735, 350, 165, 150)
        ],
        "anchor": (100, 25),
        "length": 140,
        "bottle": (825, 275)
    }


def get_level_reward(number):
    return min(number * 10, 40)


level_number = 1
current_level = 1

anchor_x = 350.0
anchor_y = 15.0
rope_length = 120.0

angle = 0.0
angular_speed = 0.0

bottle_collected = False
win_time = 0
earned_reward = 0


def get_boxes():
    return LEVELS[current_level]["boxes"]


def get_player_position():
    x = anchor_x + math.sin(angle) * rope_length
    y = anchor_y + math.cos(angle) * rope_length

    return x, y


def get_player_rect():
    x, y = get_player_position()

    return skin_images[selected_skin].get_rect(
        center=(round(x), round(y))
    )


def get_bottle_rect():
    x, y = LEVELS[current_level]["bottle"]

    return pygame.Rect(x, y, 40, 75)


def reset_level(number):
    global current_level
    global anchor_x, anchor_y, rope_length
    global angle, angular_speed
    global bottle_collected, earned_reward

    current_level = number

    info = LEVELS[number]

    anchor_x, anchor_y = info["anchor"]
    rope_length = float(info["length"])

    angle = 0.0
    angular_speed = 0.0

    bottle_collected = False
    earned_reward = 0


def hits_box():
    player_rect = get_player_rect().inflate(-24, -12)

    return any(
        player_rect.colliderect(box)
        for box in get_boxes()
    )


def attach_rope(pos):
    global anchor_x, anchor_y
    global rope_length, angle, angular_speed

    mx, my = pos

    # Цепляться можно только за коробки.
    if not any(box.collidepoint(pos) for box in get_boxes()):
        return

    px, py = get_player_position()

    dx = px - mx
    dy = py - my

    distance = math.hypot(dx, dy)

    if distance < 10:
        return

    anchor_x = float(mx)
    anchor_y = float(my)

    rope_length = distance
    angle = math.atan2(dx, dy)
    angular_speed = 0.0


def complete_level():
    global bottle_collected
    global earned_reward, coins
    global win_time, scene

    if bottle_collected:
        return

    bottle_collected = True

    earned_reward = get_level_reward(current_level)
    coins += earned_reward

    save_data()

    if win_sound:
        win_sound.play()

    win_time = pygame.time.get_ticks()
    scene = "win"


def update_level():
    global angle, angular_speed, rope_length

    keys = pygame.key.get_pressed()

    old_angle = angle
    old_length = rope_length

    if keys[pygame.K_a]:
        angular_speed -= 0.003

    if keys[pygame.K_d]:
        angular_speed += 0.003

    if keys[pygame.K_w]:
        rope_length -= 3

    if keys[pygame.K_s]:
        rope_length += 3

    rope_length = max(40, min(800, rope_length))

    angular_speed -= 0.003 * math.sin(angle)
    angular_speed *= 0.995

    angular_speed = max(
        -0.06,
        min(0.06, angular_speed)
    )

    angle += angular_speed

    if hits_box():
        angle = old_angle
        rope_length = old_length
        angular_speed = -angular_speed * 0.3

    if get_player_rect().colliderect(get_bottle_rect()):
        complete_level()


# ==========================================
# ЗАСТАВКА
# ==========================================

INTRO_DURATION = 9000
intro_start = pygame.time.get_ticks()
intro_played = False


def draw_intro():
    screen.fill(BLACK)

    draw_text(
        "ЗНАТЬ",
        intro_font,
        RED,
        (450, 170)
    )

    draw_text(
        "данная игра не хочет никого",
        small_font,
        WHITE,
        (450, 285)
    )

    draw_text(
        "оскорбить или унизить",
        small_font,
        WHITE,
        (450, 325)
    )

    draw_text(
        "спасибо за внимание",
        small_font,
        WHITE,
        (450, 365)
    )


# ==========================================
# МЕНЮ
# ==========================================

def draw_menu():
    if menu_bg:
        screen.blit(menu_bg, (0, 0))
    else:
        screen.fill(BLUE)

    draw_text(
        "СИМУЛЯТОР ЧЕКУШКИ",
        title_font,
        WHITE,
        (450, 115)
    )

    draw_button(play_button, "ИГРАТЬ")
    draw_button(skins_button, "СКИНЫ")
    draw_button(music_button, "МУЗЫКА")

    draw_back()

    draw_text(
        "-v.1.0",
        version_font,
        WHITE,
        (450, 480)
    )


# ==========================================
# ВЫБОР УРОВНЯ
# ==========================================

def draw_levels():
    screen.fill(BLUE)

    draw_back()

    draw_text(
        "ВЫБОР УРОВНЯ",
        title_font,
        WHITE,
        (450, 85)
    )

    pygame.draw.circle(
        screen,
        GREEN,
        (450, 255),
        75
    )

    pygame.draw.circle(
        screen,
        DARK_GREEN,
        (450, 255),
        75,
        5
    )

    draw_text(
        str(level_number),
        big_font,
        WHITE,
        (450, 255)
    )

    draw_arrows()

    draw_text(
        f"Награда: {get_level_reward(level_number)} монет",
        small_font,
        YELLOW,
        (450, 380)
    )


# ==========================================
# МАГАЗИН
# ==========================================

def draw_shop():
    screen.fill(BLUE)

    draw_back()

    draw_text(
        "МАГАЗИН СКИНОВ",
        title_font,
        WHITE,
        (450, 65)
    )

    draw_text(
        f"Монеты: {coins}",
        small_font,
        YELLOW,
        (760, 45)
    )

    draw_button(reset_button, "СБРОС")

    skin = SKINS[shop_index]

    draw_text(
        skin["name"],
        font,
        WHITE,
        (450, 125)
    )

    preview = pygame.transform.smoothscale(
        skin_images[shop_index],
        (115, 155)
    )

    screen.blit(
        preview,
        preview.get_rect(center=(450, 250))
    )

    draw_arrows()

    if shop_index == selected_skin:
        status = "ВЫБРАН"
        button_text = "ВЫБРАН"

    elif shop_index in owned:
        status = "УЖЕ КУПЛЕН"
        button_text = "ВЫБРАТЬ"

    else:
        status = f"Цена: {skin['price']} монет"
        button_text = "КУПИТЬ"

    draw_text(
        status,
        small_font,
        YELLOW,
        (450, 370)
    )

    draw_button(buy_button, button_text)


# ==========================================
# МУЗЫКА
# ==========================================

def draw_music_menu():
    screen.fill(BLUE)

    draw_back()

    draw_text(
        "ВЫБОР МУЗЫКИ",
        title_font,
        WHITE,
        (450, 90)
    )

    draw_text(
        TRACKS[music_index][0],
        font,
        WHITE,
        (450, 255)
    )

    draw_arrows()

    if music_enabled:
        label = "ВЫКЛЮЧИТЬ"
    else:
        label = "ВКЛЮЧИТЬ"

    draw_button(music_toggle, label)


# ==========================================
# ОТРИСОВКА ИГРЫ
# ==========================================

def draw_level():
    background = level_backgrounds[current_level]

    if background:
        screen.blit(background, (0, 0))
    else:
        screen.fill((85, 175, 245))

        for box in get_boxes():
            pygame.draw.rect(screen, BROWN, box)
            pygame.draw.rect(screen, BLACK, box, 3)

    px, py = get_player_position()

    pygame.draw.line(
        screen,
        BLACK,
        (int(anchor_x), int(anchor_y)),
        (int(px), int(py - 30)),
        3
    )

    pygame.draw.circle(
        screen,
        BLACK,
        (int(anchor_x), int(anchor_y)),
        6
    )

    player_rect = get_player_rect()

    screen.blit(
        skin_images[selected_skin],
        player_rect
    )

    if not bottle_collected:
        bottle_rect = get_bottle_rect()

        if bottle_img:
            screen.blit(bottle_img, bottle_rect)
        else:
            pygame.draw.rect(
                screen,
                (30, 180, 50),
                bottle_rect,
                border_radius=8
            )

            pygame.draw.rect(
                screen,
                WHITE,
                (
                    bottle_rect.x + 12,
                    bottle_rect.y - 8,
                    16,
                    12
                )
            )

    draw_back()

    draw_text(
        f"Уровень {current_level}",
        small_font,
        WHITE,
        (760, 35)
    )


def draw_win():
    draw_level()

    overlay = pygame.Surface(
        (WIDTH, HEIGHT),
        pygame.SRCALPHA
    )

    overlay.fill((0, 0, 0, 185))
    screen.blit(overlay, (0, 0))

    draw_text(
        "УРОВЕНЬ ПРОЙДЕН!",
        title_font,
        WHITE,
        (450, 180)
    )

    draw_text(
        f"+{earned_reward} МОНЕТ",
        big_font,
        YELLOW,
        (450, 255)
    )

    draw_text(
        f"Всего монет: {coins}",
        small_font,
        WHITE,
        (450, 330)
    )


# ==========================================
# ЗАТЕМНЕНИЕ ПО КРАЯМ
# ==========================================

vignette = pygame.Surface(
    (WIDTH, HEIGHT),
    pygame.SRCALPHA
)

for i in range(45):
    pygame.draw.rect(
        vignette,
        (0, 0, 0, 4),
        (
            i,
            i,
            WIDTH - i * 2,
            HEIGHT - i * 2
        ),
        2
    )


# ==========================================
# ПЕРЕХОДЫ МЕЖДУ ЭКРАНАМИ
# ==========================================

scene = "intro"

fade_from = "menu"
fade_to = "levels"

fade_alpha = 0
fade_phase = "out"


def start_fade(source, target):
    global scene
    global fade_from, fade_to
    global fade_alpha, fade_phase

    fade_from = source
    fade_to = target

    fade_alpha = 0
    fade_phase = "out"

    scene = "fade"


def draw_scene(name):
    if name == "intro":
        draw_intro()

    elif name == "menu":
        draw_menu()

    elif name == "levels":
        draw_levels()

    elif name == "shop":
        draw_shop()

    elif name == "music":
        draw_music_menu()

    elif name == "level":
        draw_level()

    elif name == "win":
        draw_win()


def draw_fade():
    global fade_alpha, fade_phase, scene

    if fade_phase == "out":
        draw_scene(fade_from)
        fade_alpha += 5

        if fade_alpha >= 255:
            fade_alpha = 255
            fade_phase = "in"

    else:
        draw_scene(fade_to)
        fade_alpha -= 5

        if fade_alpha <= 0:
            fade_alpha = 0
            scene = fade_to

    overlay = pygame.Surface(
        (WIDTH, HEIGHT),
        pygame.SRCALPHA
    )

    overlay.fill((0, 0, 0, fade_alpha))
    screen.blit(overlay, (0, 0))


# ==========================================
# ГЛАВНЫЙ ЦИКЛ
# ==========================================

running = True

while running:
    clock.tick(FPS)

    # Запускаем звук заставки один раз
    if scene == "intro" and not intro_played:
        intro_played = True

        if intro_sound:
            intro_sound.play()

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        # ----------------------------------
        # КЛАВИАТУРА
        # ----------------------------------

        elif event.type == pygame.KEYDOWN:

            # F11: полный экран / окно
            if event.key == pygame.K_F11:
                toggle_fullscreen()

            elif event.key == pygame.K_ESCAPE:

                if scene == "level":
                    start_fade("level", "levels")

                elif scene == "win":
                    start_fade("win", "levels")

                elif scene in ("shop", "music"):
                    start_fade(scene, "menu")

                elif scene == "levels":
                    start_fade("levels", "menu")

                elif scene == "menu":
                    running = False

        # ----------------------------------
        # МЫШЬ
        # ----------------------------------

        elif (
            event.type == pygame.MOUSEBUTTONDOWN
            and event.button == 1
        ):

            # Переводим координаты мыши
            # из разрешения монитора в 900x500.
            pos = mouse_to_game(event.pos)

            # Игнорируем нажатия на чёрные полосы.
            if not (
                0 <= pos[0] < WIDTH
                and 0 <= pos[1] < HEIGHT
            ):
                continue

            # Кнопка НАЗАД
            if scene in (
                "menu",
                "levels",
                "shop",
                "music",
                "level"
            ) and back_button.collidepoint(pos):

                if scene == "menu":
                    running = False

                elif scene == "level":
                    start_fade("level", "levels")

                elif scene == "levels":
                    start_fade("levels", "menu")

                else:
                    start_fade(scene, "menu")

                continue

            # ------------------------------
            # ГЛАВНОЕ МЕНЮ
            # ------------------------------

            if scene == "menu":

                if play_button.collidepoint(pos):
                    start_fade("menu", "levels")

                elif skins_button.collidepoint(pos):
                    start_fade("menu", "shop")

                elif music_button.collidepoint(pos):
                    start_fade("menu", "music")

            # ------------------------------
            # ВЫБОР УРОВНЯ
            # ------------------------------

            elif scene == "levels":

                if left_button.collidepoint(pos):
                    level_number = max(
                        1,
                        level_number - 1
                    )

                elif right_button.collidepoint(pos):
                    level_number = min(
                        20,
                        level_number + 1
                    )

                elif math.hypot(
                    pos[0] - 450,
                    pos[1] - 255
                ) <= 75:

                    reset_level(level_number)
                    start_fade("levels", "level")

            # ------------------------------
            # МАГАЗИН
            # ------------------------------

            elif scene == "shop":

                if reset_button.collidepoint(pos):
                    reset_shop()

                elif left_button.collidepoint(pos):
                    shop_index = (
                        shop_index - 1
                    ) % len(SKINS)

                elif right_button.collidepoint(pos):
                    shop_index = (
                        shop_index + 1
                    ) % len(SKINS)

                elif buy_button.collidepoint(pos):

                    if shop_index in owned:
                        selected_skin = shop_index
                        save_data()

                    else:
                        price = SKINS[shop_index]["price"]

                        if coins >= price:
                            coins -= price
                            owned.append(shop_index)
                            selected_skin = shop_index
                            save_data()

            # ------------------------------
            # ВЫБОР МУЗЫКИ
            # ------------------------------

            elif scene == "music":

                if left_button.collidepoint(pos):
                    music_index = (
                        music_index - 1
                    ) % len(TRACKS)

                    if music_enabled:
                        stop_music()
                        play_music()

                elif right_button.collidepoint(pos):
                    music_index = (
                        music_index + 1
                    ) % len(TRACKS)

                    if music_enabled:
                        stop_music()
                        play_music()

                elif music_toggle.collidepoint(pos):
                    music_enabled = not music_enabled

                    if music_enabled:
                        play_music()
                    else:
                        stop_music()

            # ------------------------------
            # ИГРА
            # ------------------------------

            elif scene == "level":
                attach_rope(pos)

    # ======================================
    # ОБНОВЛЕНИЕ
    # ======================================

    if (
        scene == "intro"
        and pygame.time.get_ticks() - intro_start
        >= INTRO_DURATION
    ):
        if intro_sound:
            intro_sound.stop()

        scene = "menu"

    if scene == "level":
        update_level()

    if scene == "win":
        if pygame.time.get_ticks() - win_time >= 1500:
            start_fade("win", "levels")

    # ======================================
    # РИСОВАНИЕ
    # ======================================

    if scene == "fade":
        draw_fade()
    else:
        draw_scene(scene)

    if scene != "intro":
        screen.blit(vignette, (0, 0))

    # Выводим на настоящий монитор
    present()

# ==========================================
# ВЫХОД
# ==========================================

save_data()
stop_music()

pygame.quit()
sys.exit()



